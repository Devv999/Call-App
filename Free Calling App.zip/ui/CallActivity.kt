package com.localmessenger.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.localmessenger.app.R
import com.localmessenger.app.service.CallForegroundService
import com.localmessenger.app.util.AudioHelper
import com.localmessenger.app.viewmodel.CallViewModel

class CallActivity : AppCompatActivity() {
    private val viewModel: CallViewModel by viewModels()
    private var isMuted = false
    private var isSpeakerOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        startService(Intent(this, CallForegroundService::class.java))

        viewModel.callDuration.observe(this) { duration ->
            findViewById<android.widget.TextView>(R.id.duration).text = duration
        }

        viewModel.callState.observe(this) { state ->
            if (state == CallViewModel.CallState.ENDED) {
                stopService(Intent(this, CallForegroundService::class.java))
                finish()
            }
        }

        findViewById<android.widget.ImageButton>(R.id.muteButton).setOnClickListener {
            isMuted = !isMuted
            AudioHelper.muteMicrophone(this, isMuted)
        }

        findViewById<android.widget.ImageButton>(R.id.speakerButton).setOnClickListener {
            isSpeakerOn = !isSpeakerOn
            AudioHelper.setSpeakerphoneOn(this, isSpeakerOn)
        }

        findViewById<android.widget.ImageButton>(R.id.endCallButton).setOnClickListener {
            viewModel.endCall()
        }

        // Assume WebRTC starts here with dummy IP (in real app, from Wi-Fi Direct)
        viewModel.startWebRtcCall("192.168.49.1") // Example local IP
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            viewModel.endCall()
        }
    }
}