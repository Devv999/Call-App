package com.localmessenger.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.localmessenger.app.R
import com.localmessenger.app.model.LocalUser
import com.localmessenger.app.util.PermissionHelper
import com.localmessenger.app.viewmodel.DiscoveryViewModel

class MainActivity : AppCompatActivity() {
    private val viewModel: DiscoveryViewModel by viewModels()
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!PermissionHelper.hasAllPermissions(this)) {
            PermissionHelper.requestPermissions(this, 100)
        }

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = UserAdapter { user -> onUserClicked(user) }
        recyclerView.adapter = adapter

        viewModel.discoveredUsers.observe(this) { users ->
            adapter.submitList(users)
        }

        // Prompt for display name on first launch
        if (savedInstanceState == null) {
            showNameDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.startDiscovery()
    }

    override fun onPause() {
        super.onPause()
        viewModel.stopDiscovery()
    }

    private fun showNameDialog() {
        val editText = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.enter_name))
            .setView(editText)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                viewModel.setDisplayName(editText.text.toString().ifEmpty { "User" })
            }
            .show()
    }

    private fun onUserClicked(user: LocalUser) {
        val uuid = viewModel.initiateCall(user)
        val intent = Intent(this, IncomingCallActivity::class.java).apply {
            putExtra("caller", user)
            putExtra("isInitiator", true)
        }
        startActivity(intent)
    }

    private inner class UserAdapter(private val onClick: (LocalUser) -> Unit) : RecyclerView.Adapter<UserViewHolder>() {
        private var users = listOf<LocalUser>()

        fun submitList(newUsers: List<LocalUser>) {
            users = newUsers
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): UserViewHolder {
            val view = layoutInflater.inflate(R.layout.item_user, parent, false)
            return UserViewHolder(view, onClick)
        }

        override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
            holder.bind(users[position])
        }

        override fun getItemCount() = users.size
    }

    private class UserViewHolder(itemView: android.view.View, private val onClick: (LocalUser) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val nameView: android.widget.TextView = itemView.findViewById(R.id.userName)
        private val modelView: android.widget.TextView = itemView.findViewById(R.id.deviceModel)

        fun bind(user: LocalUser) {
            nameView.text = user.displayName
            modelView.text = user.deviceModel
            itemView.setOnClickListener { onClick(user) }
        }
    }
}