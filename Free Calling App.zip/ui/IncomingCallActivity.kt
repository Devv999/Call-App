package com.localmessenger.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.localmessenger.app.R
import com.localmessenger.app.model.LocalUser
import com.localmessenger.app.viewmodel.CallViewModel

class IncomingCallActivity : AppCompatActivity() {
    private val viewModel: CallViewModel by viewModels()
    private lateinit var caller: LocalUser
    private var isInitiator = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incoming_call)

        caller = intent.getParcelableExtra("caller")!!
        isInitiator = intent.getBooleanExtra("isInitiator", false)

        findViewById<android.widget.TextView>(R.id.callerName).text = caller.displayName

        findViewById<android.widget.Button>(R.id.acceptButton).setOnClickListener {
            viewModel.acceptCall()
            startActivity(Intent(this, CallActivity::class.java))
            finish()
        }

        findViewById<android.widget.Button>(R.id.rejectButton).setOnClickListener {
            finish()
        }

        // Timeout after 30 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) finish()
        }, 30000)
    }
}