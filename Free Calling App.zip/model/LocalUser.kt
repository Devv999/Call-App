package com.localmessenger.app.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class LocalUser(
    val uuid: String,
    val displayName: String,
    val deviceModel: String
) : Parcelable