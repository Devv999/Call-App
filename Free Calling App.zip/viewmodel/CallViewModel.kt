package com.localmessenger.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.localmessenger.app.repository.WifiDirectRepository
import com.localmessenger.app.repository.WebRtcRepository
import org.webrtc.*
import java.util.*

class CallViewModel(application: Application) : AndroidViewModel(application) {
    private val wifiDirectRepository = WifiDirectRepository(application)
    private val webRtcRepository = WebRtcRepository(application)

    private val _callState = MutableLiveData<CallState>()
    val callState: LiveData<CallState> = _callState

    private val _callDuration = MutableLiveData<String>()
    val callDuration: LiveData<String> = _callDuration

    private var callStartTime: Long = 0
    private var timer: Timer? = null

    enum class CallState {
        IDLE, CONNECTING, CONNECTED, ENDED
    }

    init {
        _callState.value = CallState.IDLE
    }

    fun initiateCall(targetUuid: String) {
        _callState.value = CallState.CONNECTING
        // Assume BLE handshake sends request; here, switch to Wi-Fi Direct
        wifiDirectRepository.createGroup() // Initiator becomes Group Owner
        wifiDirectRepository.requestGroupInfo()
        wifiDirectRepository.requestConnectionInfo()
        // Wait for connection info, then proceed to WebRTC
    }

    fun acceptCall() {
        _callState.value = CallState.CONNECTING
        wifiDirectRepository.connectToDevice(/* device from BLE */ WifiP2pDevice()) // Placeholder; in real app, pass from BLE
        wifiDirectRepository.requestConnectionInfo()
        // On connection, start WebRTC
    }

    fun startWebRtcCall(remoteIp: String) {
        val peerConnection = webRtcRepository.createPeerConnection(object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate?) {
                // Send candidate over Wi-Fi Direct (simplified; use sockets for exchange)
            }

            override fun onAddStream(stream: MediaStream?) {
                // Handle remote audio track
                stream?.audioTracks?.firstOrNull()?.let { remoteTrack ->
                    // Play remote audio (WebRTC handles internally)
                }
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                if (state == PeerConnection.IceConnectionState.CONNECTED) {
                    _callState.value = CallState.CONNECTED
                    startCallTimer()
                } else if (state == PeerConnection.IceConnectionState.DISCONNECTED) {
                    endCall()
                }
            }

            // Other overrides as needed (e.g., onSignalingChange, etc.)
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onDataChannel(channel: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
        })

        // Create offer/answer based on role (simplified; exchange SDPs over Wi-Fi Direct)
        webRtcRepository.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                // Set local and send to remote
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) {}
            override fun onSetFailure(error: String?) {}
        })
    }

    fun endCall() {
        _callState.value = CallState.ENDED
        stopCallTimer()
        webRtcRepository.close()
        wifiDirectRepository.disconnect()
        // Resume BLE discovery (handled in activity)
    }

    private fun startCallTimer() {
        callStartTime = System.currentTimeMillis()
        timer = Timer()
        timer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - callStartTime) / 1000
                val minutes = elapsed / 60
                val seconds = elapsed % 60
                _callDuration.postValue(String.format("%02d:%02d", minutes, seconds))
            }
        }, 0, 1000)
    }

    private fun stopCallTimer() {
        timer?.cancel()
        timer = null
    }

    override fun onCleared() {
        super.onCleared()
        endCall()
    }
}