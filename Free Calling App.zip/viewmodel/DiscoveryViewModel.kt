package com.localmessenger.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.localmessenger.app.model.LocalUser
import com.localmessenger.app.repository.BleRepository
import com.localmessenger.app.util.NetworkUtils
import java.util.*

class DiscoveryViewModel(application: Application) : AndroidViewModel(application) {
    private val bleRepository = BleRepository(application)
    val discoveredUsers: LiveData<List<LocalUser>> = bleRepository.discoveredUsers

    private val userUuid = UUID.randomUUID().toString()
    private var displayName: String = "User" // Set via UI
    private val deviceModel = android.os.Build.MODEL

    fun startDiscovery() {
        if (NetworkUtils.isBluetoothEnabled()) {
            bleRepository.startAdvertising(userUuid, displayName, deviceModel)
            bleRepository.startScanning()
        } else {
            // Handle Bluetooth disabled (e.g., prompt user)
        }
    }

    fun stopDiscovery() {
        bleRepository.stopScanning()
        bleRepository.stopAdvertising()
    }

    fun setDisplayName(name: String) {
        displayName = name
    }

    fun initiateCall(user: LocalUser): String {
        // Return UUID for call initiation (handled in CallViewModel)
        return user.uuid
    }

    override fun onCleared() {
        super.onCleared()
        stopDiscovery()
    }
}