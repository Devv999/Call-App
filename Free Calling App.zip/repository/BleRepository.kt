package com.localmessenger.app.repository

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.localmessenger.app.model.LocalUser
import java.util.*

class BleRepository(private val context: Context) {
    private val bluetoothAdapter: BluetoothAdapter? = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val advertiser: BluetoothLeAdvertiser? = bluetoothAdapter?.bluetoothLeAdvertiser
    private val scanner: BluetoothLeScanner? = bluetoothAdapter?.bluetoothLeScanner

    private val _discoveredUsers = MutableLiveData<List<LocalUser>>()
    val discoveredUsers: LiveData<List<LocalUser>> = _discoveredUsers

    private val usersMap = mutableMapOf<String, LocalUser>()
    private val SERVICE_UUID = UUID.fromString("00001234-0000-1000-8000-00805F9B34FB") // Custom UUID for discovery

    fun startAdvertising(uuid: String, displayName: String, deviceModel: String) {
        val advertiseData = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(SERVICE_UUID))
            .addServiceData(ParcelUuid(SERVICE_UUID), "$uuid|$displayName|$deviceModel".toByteArray())
            .setIncludeDeviceName(true)
            .build()

        val advertiseSettings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(true)
            .build()

        advertiser?.startAdvertising(advertiseSettings, advertiseData, object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                super.onStartSuccess(settingsInEffect)
                // Advertising started successfully
            }

            override fun onStartFailure(errorCode: Int) {
                super.onStartFailure(errorCode)
                // Handle failure (e.g., log or notify)
            }
        })
    }

    fun startScanning() {
        val scanFilter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()

        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner?.startScan(listOf(scanFilter), scanSettings, scanCallback)
    }

    fun stopScanning() {
        scanner?.stopScan(scanCallback)
    }

    fun stopAdvertising() {
        advertiser?.stopAdvertising(object : AdvertiseCallback() {})
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.scanRecord?.serviceData?.get(ParcelUuid(SERVICE_UUID))?.let { data ->
                val dataString = String(data)
                val parts = dataString.split("|")
                if (parts.size == 3) {
                    val user = LocalUser(parts[0], parts[1], parts[2])
                    usersMap[user.uuid] = user
                    _discoveredUsers.postValue(usersMap.values.toList())
                }
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { onScanResult(ScanCallback.CALLBACK_TYPE_ALL_MATCHES, it) }
        }

        override fun onScanFailed(errorCode: Int) {
            // Handle scan failure
        }
    }
}