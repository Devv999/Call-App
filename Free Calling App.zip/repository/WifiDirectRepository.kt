package com.localmessenger.app.repository

import android.content.Context
import android.net.wifi.p2p.*
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class WifiDirectRepository(private val context: Context) {
    private val wifiP2pManager = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val channel = wifiP2pManager.initialize(context, context.mainLooper, null)

    private val _groupInfo = MutableLiveData<WifiP2pGroup?>()
    val groupInfo: LiveData<WifiP2pGroup?> = _groupInfo

    private val _connectionInfo = MutableLiveData<WifiP2pInfo?>()
    val connectionInfo: LiveData<WifiP2pInfo?> = _connectionInfo

    fun createGroup() {
        wifiP2pManager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Group created
            }

            override fun onFailure(reason: Int) {
                // Handle failure
            }
        })
    }

    fun connectToDevice(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
        }
        wifiP2pManager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Connection initiated
            }

            override fun onFailure(reason: Int) {
                // Handle failure
            }
        })
    }

    fun disconnect() {
        wifiP2pManager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Disconnected
            }

            override fun onFailure(reason: Int) {
                // Handle failure
            }
        })
    }

    val groupInfoListener = WifiP2pManager.GroupInfoListener { group ->
        _groupInfo.postValue(group)
    }

    val connectionInfoListener = WifiP2pManager.ConnectionInfoListener { info ->
        _connectionInfo.postValue(info)
    }

    fun requestGroupInfo() {
        wifiP2pManager.requestGroupInfo(channel, groupInfoListener)
    }

    fun requestConnectionInfo() {
        wifiP2pManager.requestConnectionInfo(channel, connectionInfoListener)
    }
}